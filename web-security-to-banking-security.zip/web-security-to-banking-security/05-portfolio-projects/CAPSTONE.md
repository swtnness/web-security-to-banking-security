# Portfolio Projects

## Project 1 — HTTP Request Field Notes (Week 1)
Explain an HTTPS request with a redacted DevTools capture, sequence diagram and glossary.

## Project 2 — Web Security Lab Reports (Weeks 4–7)
Publish 3–5 reports from *authorized* Web Security Academy labs. Show root cause, impact, mitigations and reproducibility within the lab only.

## Project 3 — Hardened Web App (Weeks 8–11)
Build a small app with login, user-owned records, database access and a basic API. Include tests that prove other users cannot access another user's records, prepared SQL statements, secure session handling, logging and dependency hygiene.

## Project 4 — Mock Banking App Threat Model (Weeks 12–16)
Design fake bank accounts and simulated money transfers. Demonstrate safeguards: account authorization, balance invariants, atomic ledger writes, idempotency, anti-replay, audit logs and automated negative tests. Use only synthetic identities and fake balances.

## Portfolio report structure
1. Business purpose and scope
2. Architecture and trust boundaries
3. Threat model and assumptions
4. Key controls and why they matter
5. Tests, evidence and observed results
6. Residual risks and next improvements

Be candid about what remains untested; do not describe a learning app as 'bank-grade'.

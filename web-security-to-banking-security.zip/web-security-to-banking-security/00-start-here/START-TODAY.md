# Start Today — Sunday, October 11, 2026

**Objective:** understand what happens when a browser loads a website. You do *not* need Kali Linux or hacking tools today.

## Setup (15 minutes)
1. Install or open a modern browser with Developer Tools (Chrome or Firefox).
2. Create a free account for [PortSwigger Web Security Academy](https://portswigger.net/web-security/getting-started) when ready.
3. Make sure you can open a terminal and run `git --version` (if Git is installed). Git installation can wait until Day 2.
4. Create a local folder for screenshots and notes. Do not put login tokens or personal data in the repo.

## Read (20 minutes)
- [MDN: How the Web works](https://developer.mozilla.org/en-US/docs/Learn_web_development/Getting_started/Web_standards/How_the_web_works)
- [MDN: HTTP overview](https://developer.mozilla.org/en-US/docs/Web/HTTP/Overview)

Learn these in order: client, server, URL, DNS, IP address, TLS, request, response, status code, headers, body.

## Lab 001 — Browser Developer Tools (20–30 minutes)
1. Open `https://example.com` (a public example page; **observe only**).
2. Press F12 / open Developer Tools → **Network**.
3. Reload. Select the main document request.
4. Record request method, URL, response status, and two *non-sensitive* response headers.
5. Identify the difference between request headers and response headers.
6. Write down how HTTPS differs from HTTP at a high level.

## Deliverable (10 minutes)
Create `progress/day-01-notes.md` with:
- What happened when the page loaded? (5 sentences)
- GET vs POST (one sentence each)
- HTTP status code you observed
- Screenshot with any sensitive information removed
- Two questions you still have

**Success criterion:** you can explain `browser → DNS → connection/TLS → HTTP request → response → rendering` in your own words.

## Study schedule: October 11–17
| Day | Topic | Deliverable |
|---|---|---|
| Sun 11 | How websites work; DevTools | Annotated HTTP request |
| Mon 12 | HTTP methods, URLs, status codes | 10-term mini glossary |
| Tue 13 | DNS, IP, TCP, TLS; HTTPS | Diagram of a secure request |
| Wed 14 | HTML forms and browser JavaScript | Simple HTML form (local only) |
| Thu 15 | Cookies, sessions, authentication basics | Explain how a session cookie works |
| Fri 16 | Git: init, add, commit, push | Publish study notes |
| Sat 17 | Review and knowledge check | Week 1 summary + quiz |

Try for 60 minutes daily; 30 minutes is acceptable. Do not skip building and note-taking.

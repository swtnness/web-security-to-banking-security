# Authorized Web Vulnerability Labs

Use [PortSwigger Web Security Academy](https://portswigger.net/web-security/learning-paths) or other platforms explicitly designed for practice. Select **Apprentice** labs first. Never copy these experiments onto a real banking website or any service without written permission.

## Repeatable lab report template
- **Name / date / training-lab URL:**
- **Root cause:**
- **Observed behavior:**
- **Security impact:**
- **Mitigation:**
- **How would a developer test the fix?**
- **Evidence:** redacted screenshots / output

## Topic sequence
1. SQL injection: learn data/query separation and parameterized SQL statements.
2. Cross-site scripting (XSS): learn context-aware output encoding and safe DOM APIs.
3. Cross-site request forgery (CSRF): learn CSRF tokens, SameSite, and origin checks.
4. Broken access control / IDOR: learn server-side authorization per object and action.
5. Authentication failures: learn rate limiting, MFA, reset flows and session rotation.
6. Security misconfiguration: learn secure defaults, dependency updates and error handling.

For each lab, document both the **offensive mechanism in the training environment** and the **defensive control**. Favor controlled analysis over collecting 'hacks'.

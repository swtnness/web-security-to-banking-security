# Study Progress

## Daily checklist
- [ ] Read the target material
- [ ] Complete the practical exercise
- [ ] Explain the security implication
- [ ] Commit sanitized notes/evidence
- [ ] Write what to review next

## Log
| Date | Week/day | Concept learned | Evidence link | Question / blocker |
|---|---|---|---|---|
| 2026-10-11 | W1/D1 | _To fill_ | _To fill_ | _To fill_ |

## Weekly review
- Three concepts I can explain without looking them up:
- The most useful practical skill I practiced:
- One misunderstanding I corrected:
- Next week's top priority:

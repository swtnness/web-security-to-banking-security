# Banking and Payment Application Security (Simulated Systems Only)

**Prerequisites:** web architecture, HTTP/TLS, identity, sessions, authorization, databases, API security, logging.

## Week 12: Model a mock bank
Design fake customers, fake accounts, balances and transfers. Draw trust boundaries between browser, API, ledger, identity provider, and data store. Enumerate threats using STRIDE. No real money and no real bank connection.

## Week 13: Protect money movement
Study: ledger invariants; atomic transactions; database isolation; double-spend and race-condition prevention; idempotency keys; replay protection; explicit authorization for source account; step-up authentication; transfer limits; fraud review. Never trust the client-submitted balance or account ownership claim.

**Core invariants** (for an internal ledger simulation):
- An authenticated user can initiate transfers only from accounts they are authorized to operate.
- A completed internal transfer records balanced debits/credits using a consistent ledger model.
- Duplicate retry of the same authenticated transfer intent cannot duplicate the money movement.
- Transaction and audit records are durable, attributable, time ordered, and protected against improper modification.

## Week 14: Payment ecosystems
Learn the roles of PSPs, payment gateways, tokenization, hosted payment pages, and PCI DSS scope. Use a provider's **sandbox** and official SDK if you later integrate payments. Do not collect, store, or commit real card data. Avoid creating your own payment cryptography.

## Week 15: Detection and operations
Create test cases for anomalous transfers, velocity limits, unusual login behavior, account takeover indicators, and suspicious beneficiary changes. Define monitoring and incident response with privacy-aware audit logs.

## Week 16: Security assessment
Review architecture with [OWASP ASVS](https://owasp.org/www-project-application-security-verification-standard/) and [OWASP API Security Top 10](https://owasp.org/API-Security/). Write an explicit scope, threat model, test cases, findings, mitigations, and residual-risk section.

## Useful standards and references
- OWASP ASVS: web application verification requirements
- OWASP API Security Top 10: API risks and controls
- PCI Security Standards Council: requirements relevant to cardholder data environments (scope depends on architecture)
- NIST guidance: authentication, risk management and secure development

**Important:** securing a demo is not equivalent to meeting banking-sector legal, regulatory or certification requirements.

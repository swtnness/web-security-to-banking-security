# Week 1 — Web Foundations

## Learning targets
- Explain the roles of client/browser, DNS resolver, network, web server, application, and database.
- Distinguish HTTP from HTTPS and explain what TLS protects in transit.
- Read a browser Network tab and identify HTTP methods, status codes, cookies, and response headers.
- Understand that authentication (who you are) is distinct from authorization (what you may do).

## Safe exercises
1. View your own request to `https://example.com` using DevTools; do not scan the site.
2. Sketch a web application: browser → HTTPS → reverse proxy → application → database.
3. Build a static `index.html` with a heading and a form, then view it locally.
4. Explain why client-side form validation **cannot** replace server-side validation.

## Knowledge check
- What happens before an HTTPS request can be sent?
- What is the difference between 200, 302, 401, 403, and 404?
- What information might an HTTP cookie store? What must never be exposed to JavaScript?
- What security properties does TLS provide, and what does it *not* guarantee?

## Evidence
Add a screenshot, a diagram and a 150–250 word reflection to `progress/PROGRESS.md`.

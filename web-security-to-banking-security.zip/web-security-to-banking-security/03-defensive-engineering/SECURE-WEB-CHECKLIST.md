# Defensive Web Engineering Checklist

Use [OWASP ASVS](https://owasp.org/www-project-application-security-verification-standard/) to translate principles into verifiable requirements.

## Identity & access
- [ ] Authentication is server-side; password storage uses an established password hash such as Argon2id.
- [ ] Privileged actions require appropriate MFA or step-up authentication.
- [ ] Sessions use Secure, HttpOnly, and appropriate SameSite cookie attributes; rotate identifiers on login.
- [ ] Authorization is checked on **every** request and every sensitive object; deny by default.
- [ ] Reset and recovery flows resist enumeration, replay, and account takeover.

## Input, output & APIs
- [ ] Parameterized queries; no string-concatenated SQL with untrusted input.
- [ ] Context-aware output encoding; safe DOM APIs; appropriate content security policy.
- [ ] Server validates input format and business invariants independently of UI.
- [ ] API object-level and function-level authorization tests exist.
- [ ] Rate limits and abuse controls exist for expensive/sensitive operations.

## Infrastructure & lifecycle
- [ ] TLS for transport; secrets supplied via a secrets manager or safe local environment, not Git.
- [ ] Secure default configuration and least-privilege runtime/database accounts.
- [ ] Dependencies monitored and patched; software composition analysis in CI.
- [ ] Security-relevant actions logged without credentials, tokens or sensitive payment data.
- [ ] Tested backup/restore, alerting, and incident response procedures.
- [ ] CI includes unit tests, security tests, and secret scanning.

## Verification
For each checked control, attach test evidence, not just a claim of security. Document residual risk and limitations.
